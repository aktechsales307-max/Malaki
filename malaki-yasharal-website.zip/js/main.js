const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('on'),3200)};
// header + nav
const hd=$('#top');addEventListener('scroll',()=>hd.classList.toggle('solid',scrollY>40),{passive:true});
const bg=$('.burger'),nav=$('#nav');
const closeNav=()=>{nav.classList.remove('open');bg.classList.remove('open');bg.setAttribute('aria-expanded','false')};
bg.onclick=()=>{const o=nav.classList.toggle('open');bg.classList.toggle('open',o);bg.setAttribute('aria-expanded',o)};
$$('nav a').forEach(a=>a.addEventListener('click',closeNav));
// motion
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
const bk=$('#book'),st=$('.stage'),hero=$('.hero'),intro=$('.intro'),pg=$('#prog'),mq=$('#mq'),pl2=$('#player');
const phs=$$('.card .ph');let mx=0,my=0,raf=0;
const cl=(v,a,b)=>Math.min(b,Math.max(a,v));
function tick(){raf=0;const y=scrollY,h=innerHeight,mxs=document.documentElement.scrollHeight-h;
pg.style.transform='scaleX('+(mxs>0?y/mxs:0)+')';
if(RM){bk.style.transform='rotateY(-24deg) rotateX(4deg)';return}
const k=cl(y/h,0,1);
bk.style.transform='rotateY('+(-24+mx*40+k*46)+'deg) rotateX('+(4-my*18-k*6)+'deg)';
st.style.transform='translateY('+(-y*.1)+'px)';
hero.style.setProperty('--py',(y*.28)+'px');
intro.style.transform='translateY('+(y*.14)+'px)';intro.style.opacity=cl(1-k*1.15,0,1);
const w=mq.scrollWidth/4;mq.style.transform='translateX('+(-((y*.45)%w))+'px)';
phs.forEach(p=>{const r=p.parentElement.getBoundingClientRect();p.style.setProperty('--ty',(-(r.top+r.height/2-h/2)*.09)+'px')});
const r=pl2.getBoundingClientRect();pl2.style.transform='scale('+(.88+.12*cl((h-r.top)/(h*.65),0,1))+')'}
const req=()=>{if(!raf)raf=requestAnimationFrame(tick)};
addEventListener('scroll',req,{passive:true});addEventListener('resize',req);
if(!RM&&matchMedia('(hover:hover)').matches){st.addEventListener('mousemove',e=>{const r=st.getBoundingClientRect();mx=(e.clientX-r.left)/r.width-.5;my=(e.clientY-r.top)/r.height-.5;req()});st.addEventListener('mouseleave',()=>{mx=my=0;req()})}
tick();
// reveals + counters
if(!RM&&'IntersectionObserver' in window){
document.documentElement.classList.add('js');
const L=['.about h2','.about .lead','.about .note','.portrait','.contact h2','.contact .lead'],R=['.topics li','.author h2','.author .lead','.facts div','#cf'];
const T=['.head','.about h2','.about .lead','.about .note','.topics li','blockquote','.covers figure','.card','.for .grid div','.portrait','.author h2','.author .lead','.facts div','.fmt','.opt','.news h2','.news .lead','.news form','.fb','details','.final h2','.final p','.final .btn','.contact h2','.contact .lead','#cf','.trailer h2','.trailer .lead','.stats div'];
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const el=e.target;io.unobserve(el);el.classList.add('in');setTimeout(()=>el.classList.remove('rv','in','l','r'),1400)}),{threshold:.12,rootMargin:'0px 0px -6% 0px'});
$$(T.join(',')).forEach(el=>{el.classList.add('rv');const i=[...el.parentElement.children].indexOf(el);el.style.setProperty('--d',Math.min(i,5)*.09+'s');if(L.some(q=>el.matches(q)))el.classList.add('l');else if(R.some(q=>el.matches(q)))el.classList.add('r');io.observe(el)});
const cio=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;cio.unobserve(e.target);$$('.stats b').forEach(b=>{const n=+b.textContent;if(!/^\d+$/.test(b.textContent))return;const t0=performance.now();const f=t=>{const p=cl((t-t0)/1500,0,1);b.textContent=Math.round(n*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)};b.textContent=0;requestAnimationFrame(f)})}),{threshold:.5});
cio.observe($('.stats'))}
// trailer
const pl=$('#player'),vid=$('#vid'),pb=$('#playbtn');
const start=()=>{pl.classList.add('on');vid.play().catch(()=>{})};
pb.onclick=start;vid.addEventListener('pause',()=>{if(vid.currentTime===0)pl.classList.remove('on')});
$('[data-play]').addEventListener('click',()=>setTimeout(start,700));
// formats
let cur={f:'Paperback',p:'$19.99'};
$$('.fmt').forEach(b=>b.onclick=()=>{$$('.fmt').forEach(x=>x.setAttribute('aria-pressed','false'));b.setAttribute('aria-pressed','true');cur={f:b.dataset.f,p:b.dataset.p};$('#sel').textContent=cur.f+', '+cur.p});
$('#amz').onclick=e=>{e.preventDefault();toast('Amazon link placeholder: add the book listing URL here.')};
// checkout demo
const md=$('#modal');let step=0;
const show=n=>{step=n;$$('.step').forEach(s=>s.classList.toggle('on',+s.dataset.s===n));$$('.steps i').forEach((i,k)=>i.classList.toggle('on',k<=n))};
const open=()=>{$('#mf').textContent=cur.f;$('#mp').textContent=cur.p;show(0);md.classList.add('on');$('#mx').focus()};
const close=()=>md.classList.remove('on');
$('#direct').onclick=open;$('#mx').onclick=close;$('#done').onclick=close;
md.addEventListener('click',e=>{if(e.target===md)close()});
addEventListener('keydown',e=>{if(e.key==='Escape'){close();closeNav()}});
$$('[data-next]').forEach(b=>b.onclick=()=>show(step+1));
// forms
const ok=e=>/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e);
$('#nl').onsubmit=e=>{e.preventDefault();const m=$('#nlm'),v=$('#nle').value.trim();if(!ok(v)){m.textContent='Enter a valid email address, like name@example.com.';return}m.textContent='You are on the list. This is a demo, so no email was saved.';$('#nle').value=''};
$('#cf').onsubmit=e=>{e.preventDefault();const m=$('#cfm');if(!$('#cn').value.trim()||!$('#cs').value.trim()||!$('#cm').value.trim()){m.textContent='Fill in your name, subject and message.';return}if(!ok($('#ce').value.trim())){m.textContent='Enter a valid email address.';return}m.textContent='Message sent. This is a demo, so nothing was delivered.';e.target.reset()};
