# Malaki Yasharal Author Website (concept prototype)

Static website for *The Secrets of the Prophet Daniel Finally Revealed!*
Plain HTML, CSS and JavaScript. No build step and no dependencies.

## Run locally
Open `index.html` in a browser, or run `python3 -m http.server` in this folder and visit http://localhost:8000.

## Publish with GitHub Pages
1. Create a new repository on GitHub and upload all files in this folder.
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then save.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Structure
- `index.html`: page content
- `css/style.css`: design and layout
- `js/main.js`: navigation, scroll motion, trailer, format picker, demo checkout, forms
- `assets/`: cover images, trailer video and poster

## To finish before launch
- Replace the author portrait, bio and research text (bracketed placeholders in the Author section).
- Set real prices in the Purchase section (`data-p` values and the price text).
- Add the Amazon listing URL to the "Purchase on Amazon" button (see the `#amz` handler in `js/main.js`).
- Connect a real payment provider and form service. The checkout and forms are demos only.
- The trailer is compressed to 720p. Replace `assets/trailer.mp4` with a larger file if needed.
